# P1_PRESCRIBED_ACTION

Scope: current-pinned-environment verification. Historical binary equivalence is UNRESOLVED.

## B: VERIFIED — passed

```json
{
  "status": "passed",
  "control_steps": 16,
  "solver_calls_including_resets": 484,
  "tolerance": {
    "atol": 1e-05,
    "rtol": 1e-05
  },
  "trials": 4,
  "scope": "numerical reproducibility on one seeded randomized TEST IC, not physical accuracy",
  "measured_actuator": "runtime private smoothing memory and actual _apply_action argument; no independent boundary flux measurement",
  "wall_seconds": 24.973549526184797,
  "peak_torch_cuda_allocated_bytes": 26510336
}
```


Numerical comparison table: [B/repeat_differences.csv](B/repeat_differences.csv).
INFERRED: differences describe this fixed runtime and the tested initializations only.
UNRESOLVED: physical accuracy, representation robustness and dynamics-shift sensitivity.
Numerical gate thresholds were declared before execution; failed/unrun stages are not passes.
